#!/bin/bash

echo "this is the log.sh"
